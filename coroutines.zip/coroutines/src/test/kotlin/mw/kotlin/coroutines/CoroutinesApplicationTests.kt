package mw.kotlin.coroutines

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CoroutinesApplicationTests {

	@Test
	fun contextLoads() {
	}

}
